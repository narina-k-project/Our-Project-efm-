package com.example.project;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Card {
    String title;
    String content;
    static JSONArray cards = new JSONArray();

    Card(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public JSONArray create() throws JSONException {
        JSONObject object = new JSONObject();
        object.put("title", title);
        object.put("content", content);
        cards.put(object);
        return cards;
    }
}

