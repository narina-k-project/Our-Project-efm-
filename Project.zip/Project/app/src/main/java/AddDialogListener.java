import android.support.design.widget.Snackbar;
import android.support.v4.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.view.View;

import com.example.project.R;

import static android.support.v4.graphics.drawable.IconCompat.getResources;

public interface AddDialogListener {
    View rv = ;

    void onDialogPositiveClick(DialogFragment dialog);

    @Override

    String buttonName = getResources().getString(R.string.dialog_positive_button);
        Snackbar mSnackbar = Snackbar.make(rv, "Этот Snackbar появляется после нажатия кнопки \""+buttonName+"\" в диалоговом окне", Snackbar.LENGTH_INDEFINITE)
                .setAction("Action", null);

        View snackbarView = mSnackbar.getView();
        snackbarView.setBackgroundColor(ContextCompat.getColor(getApplicationContext(), R.color.colorMyGreenDark));
        mSnackbar.show();
    }
    

